Schritt 1: Klicken Sie auf JavaSetup8u251.exe und führen Sie die Installation durch.

Schritt 2: Sobald die Installation erfolgreich durchgeführt wurde klicken Sie auf MauMau.jar, nun startet das Spiel